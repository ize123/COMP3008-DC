﻿using ServiceInterface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DuplexClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public delegate void ProcessLongTask();

    public partial class MainWindow : Window
    {
        private ProcessServiceInterface foob;
        private ProcessServiceCallback foobCallback;
        private ProcessLongTask longTask;
        IAsyncResult asyncResult;
        public MainWindow()
        {
            InitializeComponent();
            DuplexChannelFactory<ProcessServiceInterface> foobFactory;
            NetTcpBinding netTcpBinding = new NetTcpBinding();
            string URL = "net.tcp://localhost:8100/ProcessService";
            foobCallback = new ProcessServiceCallBackImpl(this);
            foobFactory = new DuplexChannelFactory<ProcessServiceInterface>
                (foobCallback, netTcpBinding, URL);
            foob = foobFactory.CreateChannel();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            longTask = foob.ProcessLongTask;
            asyncResult = longTask.BeginInvoke(null, null);
            //foob.ProcessLongTask();
        }
        
        public void Progress(int percentageCompleted)
        {   
            PBarProcess.Dispatcher.Invoke(new Action(() => {PBarProcess.Value = percentageCompleted;}));
            if (percentageCompleted == 100)
            {
                asyncResult.AsyncWaitHandle.Close();
            }
        }
    }
}
