﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using ServiceInterface;

namespace DuplexServer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Duplex Sever. I send progress update");
           
            NetTcpBinding netTcpBinding = new NetTcpBinding();
            ServiceHost serviceHost = new ServiceHost(typeof(ProcessServiceImplement));
            serviceHost.AddServiceEndpoint(typeof(ProcessServiceInterface), 
                netTcpBinding, "net.tcp://0.0.0.0:8100/ProcessService");
            serviceHost.Open();
            Console.WriteLine("System online");
            Console.ReadLine();
            serviceHost.Close();
        }
    }
}
