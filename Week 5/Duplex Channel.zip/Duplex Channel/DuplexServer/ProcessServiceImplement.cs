﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ServiceInterface;

namespace DuplexServer
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, 
        UseSynchronizationContext =false)]
    internal class ProcessServiceImplement : ProcessServiceInterface
    {
       
        public void ProcessLongTask()
        {
            for(int i = 1; i <= 100; i++)
            {
                Thread.Sleep(50);
                OperationContext.Current.
                    GetCallbackChannel<ProcessServiceCallback>().Progress(i);
            }
        }
    }
}
