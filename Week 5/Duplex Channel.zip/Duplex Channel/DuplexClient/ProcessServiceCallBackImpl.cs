﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using ServiceInterface;

namespace DuplexClient
{
    [CallbackBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, UseSynchronizationContext = false)]
    internal class ProcessServiceCallBackImpl : ProcessServiceCallback
    {
        private MainWindow window;

        public ProcessServiceCallBackImpl(MainWindow window)
        {
            this.window = window;
        }
        public void Progress(int percentageMainCompleted)
        {
            window.Progress(percentageMainCompleted);
        }
    }
}
